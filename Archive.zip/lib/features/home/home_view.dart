import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kayasmart_case/components/custom_circle.dart';
import 'package:kayasmart_case/components/custom_ellipse.dart';
import 'package:kayasmart_case/components/custom_image.dart';
import 'package:kayasmart_case/components/custom_line.dart';
import 'package:kayasmart_case/components/custom_polygon.dart';
import 'package:kayasmart_case/components/custom_rectangle.dart';
import 'package:kayasmart_case/components/custom_text.dart';
import 'package:kayasmart_case/constants/layer_types.dart';
import 'package:kayasmart_case/models/data_model.dart';
import 'package:kayasmart_case/models/layer_model.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  DataModel? dataModel;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    String jsonString = await rootBundle.loadString('assets/data.json');
    Map<String, dynamic> json = jsonDecode(jsonString);

    setState(() {
      dataModel = DataModel.fromJson(json);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: dataModel == null
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SafeArea(
              child: SizedBox(
                width: double.infinity,
                height: double.infinity,
                child: Stack(
                  children: buildLayers(
                    dataModel?.layers ?? [],
                  ), // dataModel is non-null here
                ),
              ),
            ),
    );
  }

  List<Widget> buildLayers(List<LayerModel> layers) {
    return layers.map((layer) {
      switch (layer.type) {
        case LayerType.circle:
          return CustomCircle(layer: layer);
        case LayerType.ellipse:
          return CustomEllipse(layer: layer);
        case LayerType.line:
          return CustomLine(layer: layer);
        case LayerType.polygon:
          return CustomPolygon(layer: layer);
        case LayerType.image:
          return CustomImage(layer: layer);
        case LayerType.text:
          return CustomText(layer: layer);
        case LayerType.rectangle:
          return CustomRectangle(layer: layer);
        default:
          return const Text('Layer could not be drawed');
      }
    }).toList();
  }
}
