import 'package:flutter/material.dart';
import 'package:kayasmart_case/extensions/color.dart';
import 'package:kayasmart_case/models/layer_model.dart';

class CustomCircle extends StatelessWidget {
  final LayerModel layer;
  const CustomCircle({
    super.key,
    required this.layer,
  });

  @override
  Widget build(BuildContext context) {
    if (layer.position == null || layer.color == null || layer.radius == null) {
      return const SizedBox();
    }
    return Positioned(
      top: layer.position!.y,
      left: layer.position!.x,
      child: Container(
        width: layer.radius,
        height: layer.radius,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: HexColor.colorFromHex(layer.color!),
        ),
      ),
    );
  }
}
