import 'package:flutter/material.dart';
import 'package:kayasmart_case/extensions/color.dart';
import 'package:kayasmart_case/models/layer_model.dart';

class CustomRectangle extends StatelessWidget {
  final LayerModel layer;
  const CustomRectangle({super.key, required this.layer});

  @override
  Widget build(BuildContext context) {
    if (layer.position == null || layer.color == null) {
      return const SizedBox();
    }

    return Positioned(
      left: layer.position!.x ?? 0,
      top: layer.position!.y ?? 0,
      child: Container(
        height: layer.height ?? 0,
        width: layer.width ?? 0,
        color: HexColor.colorFromHex(layer.color!),
      ),
    );
  }
}
