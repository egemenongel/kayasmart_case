import 'package:flutter/material.dart';
import 'package:kayasmart_case/models/layer_model.dart';

class CustomImage extends StatelessWidget {
  const CustomImage({
    super.key,
    required this.layer,
  });
  final LayerModel layer;
  @override
  Widget build(BuildContext context) {
    if (layer.position == null || layer.url == null) {
      return const SizedBox();
    }

    return Positioned(
      top: layer.position!.y ?? 0,
      left: layer.position!.x ?? 0,
      child: Image.network(
        layer.url ?? '',
        height: layer.height,
        width: layer.width,
      ),
    );
  }
}
