import 'package:flutter/material.dart';
import 'package:kayasmart_case/extensions/color.dart';
import 'package:kayasmart_case/models/layer_model.dart';

class CustomText extends StatelessWidget {
  const CustomText({super.key, required this.layer});
  final LayerModel layer;

  @override
  Widget build(BuildContext context) {
    if (layer.position == null || layer.value == null || layer.color == null) {
      return const SizedBox();
    }

    return Positioned(
      left: layer.position!.x ?? 0,
      top: layer.position!.y ?? 0,
      child: Text(
        layer.value!,
        style: TextStyle(
          fontSize: layer.fontSize ?? 14,
          color: HexColor.colorFromHex(layer.color!),
        ),
      ),
    );
  }
}
