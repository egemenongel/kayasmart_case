package com.example.kayasmart_case

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
